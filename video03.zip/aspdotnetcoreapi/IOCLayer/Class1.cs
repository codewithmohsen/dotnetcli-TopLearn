﻿namespace IOCLayer;

public class Class1
{

}
