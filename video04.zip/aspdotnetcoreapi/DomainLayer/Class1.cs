﻿namespace DomainLayer;

public class Class1
{

}
